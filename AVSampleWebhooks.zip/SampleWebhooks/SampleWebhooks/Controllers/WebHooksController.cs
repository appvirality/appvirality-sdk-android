﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.IO;
using System.Text;
using System.Web.Script.Serialization;

namespace SampleWebhooks.Controllers
{
    public class WebHooksController : ApiController
    {
        /// <summary>
        /// Method to accept Conversion Event web hook.
        /// </summary>
        /// <param name="inputdata"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/onconversionsuccess")]
        public HttpResponseMessage OnConversionSuccess(Models.WebHookModel inputdata)
        {
            HttpResponseMessage response = null;
            string strFrndStatus = string.Empty;
            string strRefStatus = string.Empty;
            try
            {
                string securekey = inputdata.securekey;
                //Checking Secure Key
                if (securekey.Equals(System.Configuration.ConfigurationManager.AppSettings["SecureKey"]))
                {
                    //Accessing details
                    bool success = inputdata.success;
                    string campaignid = inputdata.campaignid;
                    string campaignname = inputdata.campaignname;
                    string eventname = inputdata.eventname;
                    string extraInfo = inputdata.extraInfo;

                    //Accessing friend details
                    string friendparticipantid = inputdata.friend.participantid;
                    string friendemailid = inputdata.friend.emailid;
                    string friendname = inputdata.friend.name;
                    string friendstoreuserid = inputdata.friend.storeuserid;
                    string friendrewardid = inputdata.friend.rewardid;
                    string friendrewarddtlid = inputdata.friend.rewarddtlid;
                    string friendreward_type = inputdata.friend.reward_type;
                    string friendrewarded_date = inputdata.friend.rewarded_date;
                    string friendamount = inputdata.friend.amount;
                    string friendreward_unit = inputdata.friend.reward_unit;
                    string friendreward_description = inputdata.friend.reward_description;
                    string friendcouponcode = inputdata.friend.couponcode;
                    string friendplatform = inputdata.friend.platform;
                    string friendexpires = inputdata.friend.expires;

                    //Accessing Referrer details
                    string referrerparticipantid = inputdata.referrer.participantid;
                    string referreremailid = inputdata.referrer.emailid;
                    string referrername = inputdata.referrer.name;
                    string referrerstoreuserid = inputdata.referrer.storeuserid;
                    string referrerrewarddtlid = inputdata.referrer.rewarddtlid;
                    string referrerrewarded_date = inputdata.referrer.rewarded_date;
                    string referreramount = inputdata.referrer.amount;
                    string referrerreward_unit = inputdata.referrer.reward_unit;
                    string referrerreward_description = inputdata.referrer.reward_description;
                    string referrerreviewperiod = inputdata.referrer.reviewperiod;
                    string referrerplatform = inputdata.referrer.platform;

                    //Check if Friend is Rewarded 
                    if (!string.IsNullOrEmpty(friendrewarddtlid))
                    {
                        //Calling Check Reward Status Method to check friend reward status
                        strFrndStatus = CheckRewardStatus(friendrewarddtlid);
                    }

                    //Redeem Friend Rewards if friend reward status is approved
                    if (!string.IsNullOrEmpty(friendrewarddtlid) && strFrndStatus.Equals("approved", StringComparison.OrdinalIgnoreCase))
                    {
                        /* -------------------------------------
                        ADD YOUR CODE FOR CREDITING FRIEND REWARD AMOUNT TO WALLET
                        --------------------------------------*/

                        var rwds = new List<Models.FriendReward>();
                        var rwd = new Models.FriendReward();
                        rwd.rewardid = friendrewarddtlid;
                        rwd.reward_type = friendreward_type;
                        rwd.status = "Distribute";
                        rwds.Add(rwd);
                        //Redeem Friend Rewards
                        bool isProcessed = RedeemFriendRewards(rwds);
                    }



                    //Check if Referrer is Rewarded
                    if (!string.IsNullOrEmpty(referrerrewarddtlid))
                    {
                        //Calling Check Reward Status Method to check referrer reward status
                        strRefStatus = CheckRewardStatus(referrerrewarddtlid);
                    }

                    //Redeem Referrer Rewards if referrer reward status is approved
                    if (!string.IsNullOrEmpty(referrerrewarddtlid) && !string.IsNullOrEmpty(referrerparticipantid) && strRefStatus.Equals("approved", StringComparison.OrdinalIgnoreCase))
                    {

                        /* -------------------------------------
                        ADD YOUR CODE FOR CREDITING REFERRER REWARD AMOUNT TO WALLET
                        --------------------------------------*/

                        var rwds = new List<Models.ReferrerReward>();
                        var rwd = new Models.ReferrerReward();
                        rwd.participantid = referrerparticipantid;

                        rwd.rewarddetails = new List<Models.ReferrerRewardDetail>();
                        rwd.rewarddetails.Add(new Models.ReferrerRewardDetail() { rewarddtlid = referrerrewarddtlid });
                        // Or We can do with the amount
                        rwd.amount = referreramount;

                        rwds.Add(rwd);
                        //Redeem Referrer Rewards
                        bool isProcessed = RedeemReferrerRewards(rwds);
                    }
                    response = Request.CreateResponse(HttpStatusCode.OK, "Process completed successfully.");
                }
                else
                    response = Request.CreateResponse(HttpStatusCode.Unauthorized, "");
            }
            catch (Exception ex)
            {
                //Log Exception
                response = Request.CreateResponse(HttpStatusCode.InternalServerError, "Error processing Reward.");
            }
            return response;
        }

        /// <summary>
        /// Method to process Friend Reward WebHook call.
        /// </summary>
        /// <param name="inputdata"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/onrewardingfriend")]
        public HttpResponseMessage OnRewardingFriend(Models.WebHookModel inputdata)
        {
            HttpResponseMessage response = null;
            string strFrndStatus = string.Empty;
            try
            {
                string securekey = inputdata.securekey;
                //Checking Secure Key
                if (securekey.Equals(System.Configuration.ConfigurationManager.AppSettings["SecureKey"]))
                {
                    //Accessing details
                    bool success = inputdata.success;
                    string campaignid = inputdata.campaignid;
                    string campaignname = inputdata.campaignname;
                    string eventname = inputdata.eventname;
                    string extraInfo = inputdata.extraInfo;

                    //Accessing friend details
                    string friendparticipantid = inputdata.friend.participantid;
                    string friendemailid = inputdata.friend.emailid;
                    string friendname = inputdata.friend.name;
                    string friendstoreuserid = inputdata.friend.storeuserid;
                    string friendrewardid = inputdata.friend.rewardid;
                    string friendrewarddtlid = inputdata.friend.rewarddtlid;
                    string friendreward_type = inputdata.friend.reward_type;
                    string friendrewarded_date = inputdata.friend.rewarded_date;
                    string friendamount = inputdata.friend.amount;
                    string friendreward_unit = inputdata.friend.reward_unit;
                    string friendreward_description = inputdata.friend.reward_description;
                    string friendcouponcode = inputdata.friend.couponcode;
                    string friendplatform = inputdata.friend.platform;
                    string friendexpires = inputdata.friend.expires;

                    //Accessing Referrer details
                    string referrerparticipantid = inputdata.referrer.participantid;
                    string referreremailid = inputdata.referrer.emailid;
                    string referrername = inputdata.referrer.name;
                    string referrerstoreuserid = inputdata.referrer.storeuserid;
                    string referrerplatform = inputdata.referrer.platform;

                    //Check if Friend is Rewarded 
                    if (!string.IsNullOrEmpty(friendrewarddtlid))
                    {
                        //Calling Check Reward Status Method to check friend reward status
                        strFrndStatus = CheckRewardStatus(friendrewarddtlid);
                    }

                    //Redeem Friend Rewards if friend reward status is approved
                    if (strFrndStatus.Equals("approved", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrEmpty(friendrewarddtlid))
                    {

                        /* -------------------------------------
                        ADD YOUR CODE FOR CREDITING AMOUNT TO WALLET
                        --------------------------------------*/

                        var rwds = new List<Models.FriendReward>();
                        var rwd = new Models.FriendReward();
                        rwd.rewardid = friendrewarddtlid;
                        rwd.reward_type = friendreward_type;
                        rwd.status = "Distribute";
                        rwds.Add(rwd);
                        //Redeem Friend Rewards
                        bool isProcessed = RedeemFriendRewards(rwds);
                    }
                    response = Request.CreateResponse(HttpStatusCode.OK, "Process completed successfully.");
                }
                else
                    response = Request.CreateResponse(HttpStatusCode.Unauthorized, "");
            }
            catch (Exception ex)
            {
                //Log Exception
                response = Request.CreateResponse(HttpStatusCode.InternalServerError, "Error processing Reward.");
            }
            return response;
        }

        /// <summary>
        /// Method to process Referrer Reward WebHook call.
        /// </summary>
        /// <param name="inputdata"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("api/onrewardingreferrer")]
        public HttpResponseMessage OnRewardingReferrer(Models.ReferrerDetails inputdata)
        {
            HttpResponseMessage response = null;
            try
            {
                string securekey = inputdata.securekey;
                //Checking Secure Key
                if (securekey.Equals(System.Configuration.ConfigurationManager.AppSettings["SecureKey"]))
                {
                    //Accessing referrer details
                    string referreremailid = inputdata.emailid;
                    string referrername = inputdata.name;
                    string referrerstoreuserid = inputdata.storeuserid;
                    string campaignid = inputdata.campaignid;
                    string campaignname = inputdata.campaignname;
                    string referrerparticipantid = inputdata.participantid;
                    string rewardid = inputdata.rewardid;
                    string reward_type = inputdata.reward_type;
                    string referrerrewarded_date = inputdata.rewarded_date;
                    string referreramount = inputdata.amount;
                    string referrerreward_unit = inputdata.reward_unit;
                    string referrerreward_description = inputdata.reward_description;
                    string couponcode = inputdata.couponcode;
                    string expires = inputdata.expires;
                    string referrerplatform = inputdata.platform;

                    //Redeem Referrer Rewards
                    if (!string.IsNullOrEmpty(referrerparticipantid))
                    {

                        /* -------------------------------------
                        ADD YOUR CODE FOR CREDITING AMOUNT TO WALLET
                        --------------------------------------*/

                        var rwds = new List<Models.ReferrerReward>();
                        var rwd = new Models.ReferrerReward();
                        rwd.participantid = referrerparticipantid;

                        rwd.rewarddetails = (from c in inputdata.rewarddetails
                                             select new Models.ReferrerRewardDetail() { rewarddtlid = c.rewarddtlid }).ToList();
                        // Or We can do with the amount
                        rwd.amount = referreramount;

                        rwds.Add(rwd);
                        //Redeem Referrer Rewards
                        bool isProcessed = RedeemReferrerRewards(rwds);
                    }
                    response = Request.CreateResponse(HttpStatusCode.OK, "Process completed successfully.");
                }
                else
                    response = Request.CreateResponse(HttpStatusCode.Unauthorized, "");
            }
            catch (Exception ex)
            {
                //Log Exception
                response = Request.CreateResponse(HttpStatusCode.InternalServerError, "Error processing Reward.");
            }
            return response;
        }

        /// <summary>
        /// API call to check friend/referrer status. It verifies the compliance to fraud checks enabled
        /// </summary>
        /// <param name="rewarddtlid">Reward Detail Id</param>
        /// <returns></returns>
        private string CheckRewardStatus(string rewarddtlid)
        {
            string url = System.Configuration.ConfigurationManager.AppSettings["CheckRewardStatusURL"];
            Models.CheckRewardStatusInput input = new Models.CheckRewardStatusInput();
            input.apikey = System.Configuration.ConfigurationManager.AppSettings["APIKey"];
            input.privatekey = System.Configuration.ConfigurationManager.AppSettings["PrivateKey"];
            input.rewarddtlid = rewarddtlid;

            JavaScriptSerializer json_serializer = new JavaScriptSerializer();
            string data = json_serializer.Serialize(input);
            string resp = CallService(url, data);
            Models.CheckRewardStatusOutput output = json_serializer.Deserialize<Models.CheckRewardStatusOutput>(resp);
            return output.reward_status;
        }

        /// <summary>
        /// API call to Redeem Friend Rewards. It marks the rewards as Rewarded / Distributed
        /// </summary>
        /// <param name="rwds">List of rewards</param>
        /// <returns></returns>
        private bool RedeemFriendRewards(List<Models.FriendReward> rwds)
        {
            string url = System.Configuration.ConfigurationManager.AppSettings["RedeemFriendRewardsURL"];
            Models.RedeemFriendRewardsInput input = new Models.RedeemFriendRewardsInput();
            input.apikey = System.Configuration.ConfigurationManager.AppSettings["APIKey"];
            input.privatekey = System.Configuration.ConfigurationManager.AppSettings["PrivateKey"];
            input.rewards = rwds;

            JavaScriptSerializer json_serializer = new JavaScriptSerializer();
            string data = json_serializer.Serialize(input);
            string resp = CallService(url, data);
            Models.RedeemFriendRewardsOutput output = json_serializer.Deserialize<Models.RedeemFriendRewardsOutput>(resp);
            return output.success;
        }

        /// <summary>
        /// API call to Redeem Referrer Rewards. It marks the referrer rewards as Rewarded / Distributed.
        /// </summary>
        /// <param name="rwds">List of rewards</param>
        /// <returns></returns>
        private bool RedeemReferrerRewards(List<Models.ReferrerReward> rwds)
        {
            string url = System.Configuration.ConfigurationManager.AppSettings["RedeemReferrerRewardsURL"];
            Models.RedeemReferrerRewardsInput input = new Models.RedeemReferrerRewardsInput();
            input.apikey = System.Configuration.ConfigurationManager.AppSettings["APIKey"];
            input.privatekey = System.Configuration.ConfigurationManager.AppSettings["PrivateKey"];
            input.rewards = rwds;

            JavaScriptSerializer json_serializer = new JavaScriptSerializer();
            string data = json_serializer.Serialize(input);
            string resp = CallService(url, data);
            Models.RedeemReferrerRewardsOutput output = json_serializer.Deserialize<Models.RedeemReferrerRewardsOutput>(resp);
            return output.success;
        }

        /// <summary>
        /// Send JSON data to specified URL using HTTP Post Method
        /// </summary>
        /// <param name="url">Post URL</param>
        /// <param name="postData">JSON Data</param>
        /// <returns></returns>
        private string CallService(string url, string postData)
        {
            string resp = string.Empty;

            var httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            httpWebRequest.UserAgent = "SampleWebhooks(Change it accordingly)";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(postData);
                streamWriter.Flush();
                streamWriter.Close();

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                if (httpResponse.StatusCode == HttpStatusCode.OK)
                {
                    using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    {
                        resp = streamReader.ReadToEnd();
                    }
                }
            }
            return resp;
        }
    }
}
