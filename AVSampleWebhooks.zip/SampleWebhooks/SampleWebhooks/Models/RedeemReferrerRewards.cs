﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleWebhooks.Models
{
    public class RedeemReferrerRewardsInput
    {
        public string apikey { get; set; }
        public string privatekey { get; set; }
        public List<ReferrerReward> rewards { get; set; }
    }

    public class ReferrerReward
    {
        public string participantid { get; set; }
        public string amount { get; set; }
        public List<ReferrerRewardDetail> rewarddetails { get; set; }
    }

    public class ReferrerRewardDetail
    {
        public string rewarddtlid { get; set; }
    }

    public class RedeemReferrerRewardsOutput
    {
        public bool success { get; set; }
        public string message { get; set; }
    }
}