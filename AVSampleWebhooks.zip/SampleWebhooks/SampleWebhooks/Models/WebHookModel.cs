﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleWebhooks.Models
{
    public class WebHookModel
    {
        public string securekey { get; set; }
        public bool success { get; set; }
        public string campaignid { get; set; }
        public string campaignname { get; set; }
        public string eventname { get; set; }
        public string extraInfo { get; set; }
        public Friend friend { get; set; }
        public Referrer referrer { get; set; }
        public string message { get; set; }
    }

    public class Friend
    {
        public string participantid { get; set; }
        public string emailid { get; set; }
        public string name { get; set; }
        public string storeuserid { get; set; }
        public string rewardid { get; set; }
        public string rewarddtlid { get; set; }
        public string reward_type { get; set; }
        public string rewarded_date { get; set; }
        public string amount { get; set; }
        public string reward_unit { get; set; }
        public string reward_description { get; set; }
        public string couponcode { get; set; }
        public string expires { get; set; }
        public string platform { get; set; }
    }

    public class Referrer
    {
        public string participantid { get; set; }
        public string emailid { get; set; }
        public string name { get; set; }
        public string storeuserid { get; set; }
        public string rewarddtlid { get; set; }
        public string rewarded_date { get; set; }
        public string amount { get; set; }
        public string reward_unit { get; set; }
        public string reward_description { get; set; }
        public string reviewperiod { get; set; }
        public string platform { get; set; }
        public string rewardid { get; set; }
        public string couponcode { get; set; }
        public string reward_type { get; set; }
        public string expires { get; set; }
    }
}