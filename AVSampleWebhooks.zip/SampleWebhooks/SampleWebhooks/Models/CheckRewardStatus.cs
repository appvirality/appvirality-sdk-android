﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleWebhooks.Models
{
    public class CheckRewardStatusInput
    {
        public string apikey { get; set; }
        public string privatekey { get; set; }
        public string rewarddtlid { get; set; }
    }

    public class CheckRewardStatusOutput
    {
        public bool success { get; set; }
        public string rewarddtlid { get; set; }
        public string reward_status { get; set; }
        public string comment { get; set; }
    }
}