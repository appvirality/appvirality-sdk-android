﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SampleWebhooks.Models
{
    public class RedeemFriendRewardsInput
    {
        public string apikey { get; set; }
        public string privatekey { get; set; }
        public List<FriendReward> rewards { get; set; }
    }

    public class FriendReward
    {
        public string rewardid { get; set; }
        public string reward_type { get; set; }
        public string status { get; set; }
    }

    public class RedeemFriendRewardsOutput
    {
        public bool success { get; set; }
        public string message { get; set; }
    }
}